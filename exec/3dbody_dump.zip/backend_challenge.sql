CREATE DATABASE  IF NOT EXISTS `backend` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `backend`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: c204.cjw2k0eykv8p.ap-northeast-2.rds.amazonaws.com    Database: backend
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `challenge`
--

DROP TABLE IF EXISTS `challenge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `challenge` (
  `challenge_id` bigint NOT NULL AUTO_INCREMENT,
  `content` text COLLATE utf8mb4_general_ci NOT NULL,
  `end_date` datetime(6) NOT NULL,
  `entry` int NOT NULL DEFAULT '0',
  `hit` int NOT NULL DEFAULT '0',
  `image` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `start_date` datetime(6) NOT NULL,
  `status` enum('BEFORE','PROCEEDING','FINISHED') COLLATE utf8mb4_general_ci DEFAULT NULL,
  `summary` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `thumbnail` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`challenge_id`),
  KEY `FKotphd6wl9f0ur0uw1y9g4ypt2` (`user_id`),
  CONSTRAINT `FKotphd6wl9f0ur0uw1y9g4ypt2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `challenge`
--

LOCK TABLES `challenge` WRITE;
/*!40000 ALTER TABLE `challenge` DISABLE KEYS */;
INSERT INTO `challenge` VALUES (6,'te','2024-02-11 09:00:00.000000',0,0,'https://do9nz79ez57wg.cloudfront.net/d213050a-5912-037c-5d88-14afaf848c50_apple-touch-icon-180x180.png','2024-02-11 09:00:00.000000',NULL,'te','https://do9nz79ez57wg.cloudfront.net/86947e1c-4891-d9b5-0b2a-6abcd2eb695b_apple-touch-icon-180x180.png','te',1),(12,'test','2024-02-13 09:00:00.000000',0,1,'https://do9nz79ez57wg.cloudfront.net/5f135d0a-76e2-43c2-1a69-47a9685e8cba_닉퓨리.jpg','2024-02-13 09:00:00.000000',NULL,'test','https://do9nz79ez57wg.cloudfront.net/3beccfaf-e8d5-7271-0dd5-e8ea47b547ec_닉퓨리.jpg','test',1),(16,'참가하기를 눌러주면 커피 기프티콘을 드립니다! 많은 참여 부탁드립니다.','2024-02-21 09:00:00.000000',5,26970,'https://do9nz79ez57wg.cloudfront.net/6864b076-c163-6515-6392-f27874e11821_제목을 입력해주세요_-001 (3).png','2024-02-08 09:00:00.000000',NULL,'쓰리디바디가 뿌린다! 신년 이벤트!','https://do9nz79ez57wg.cloudfront.net/a1c12284-429b-f65e-4991-83141b139c9f_제목을 입력해주세요_-001 (1).png','선물받아가세요!!챌린지!',5),(26,'플랭크에 자신 있으시다구요????\n지금 바로 3Dbody에서 플랭크 대결에 참여해 보세요!!!','2024-02-16 09:00:00.000000',5,1326,'https://do9nz79ez57wg.cloudfront.net/73d2f0d0-7d32-3859-2199-4fb1502bc838_플랭크챌린지이미지.png','2024-02-01 09:00:00.000000',NULL,'플랭크를 오래오래 버텨 보세요!','https://do9nz79ez57wg.cloudfront.net/d7e663ef-ae4c-93aa-4902-4c96b73a72fc_플랭크챌린지썸네일.png','이건 내가 최고 플랭크',6),(27,'지금 당장 스쿼트 대결에 참여해 보세요!!!\n스쿼트의 대장은 과연 누가 될것인가\n\n참가자들 중 추첨을 통하여 커피 기프티콘을 드립니다. 많은 참여 부탁드립니다!!!','2024-02-29 09:00:00.000000',0,338,'https://do9nz79ez57wg.cloudfront.net/ecd33376-ec59-8da5-3f8a-76f24a5149ef_스쿼트챌린지이미지.png','2024-02-15 09:00:00.000000',NULL,'다함께 스쿼트 도전해보자!','https://do9nz79ez57wg.cloudfront.net/f959e1d1-bbeb-efcd-e03e-1b9583404238_스쿼트챌린지썸네일.png','LIVE 스쿼트 챌린지',6),(28,'2월15일부터 25일까지 10일간 7만보 걷기 챌린지가 진행됩니다!\n챌린지를 통해 다함께 7만보 걷기 달성해봐요~','2024-02-25 09:00:00.000000',0,393,'https://do9nz79ez57wg.cloudfront.net/f2ca852e-8fec-2b6e-badb-dbe1c03aa177_7만보걷기챌린지썸네일.png','2024-02-15 09:00:00.000000',NULL,'우리모두 건강을 위해 걷기 챌린지 도전해봐요!','https://do9nz79ez57wg.cloudfront.net/36bbe761-a9ef-7866-56d8-9c23356002d8_7만보걷기챌린지썸네일.png','7만보 걷기 챌린지',6),(29,'2024년 갑진년 새해를 맞아 러닝 챌린지가 진행됩니다. 지금 바로 참여해보세요!','2024-02-17 09:00:00.000000',1,6492,'https://do9nz79ez57wg.cloudfront.net/5fec3a93-c899-d8ee-ffc5-3e3e5b6614ec_신년러닝챌린지썸네일.png','2024-02-15 09:00:00.000000',NULL,'새해맞이 러닝 챌린지 오픈!','https://do9nz79ez57wg.cloudfront.net/3a42cdf3-155f-2e60-be71-f47b41378435_신년러닝챌린지썸네일.png','신년 러닝 챌린지',6);
/*!40000 ALTER TABLE `challenge` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-15 22:17:57
