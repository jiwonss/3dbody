CREATE DATABASE  IF NOT EXISTS `backend` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `backend`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: c204.cjw2k0eykv8p.ap-northeast-2.rds.amazonaws.com    Database: backend
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `training`
--

DROP TABLE IF EXISTS `training`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `training` (
  `training_id` bigint NOT NULL AUTO_INCREMENT,
  `category` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`training_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training`
--

LOCK TABLES `training` WRITE;
/*!40000 ALTER TABLE `training` DISABLE KEYS */;
INSERT INTO `training` VALUES (1,'하체','https://do9nz79ez57wg.cloudfront.net/32af05f4-01d9-4ee7-b9a6-a7d13d47124e_바벨스쿼트.gif','바벨 스쿼트'),(2,'하체','https://do9nz79ez57wg.cloudfront.net/07b287e5-8dda-4480-985d-5a3fd08390d4_바벨핵스쿼트.jpg','바벨 핵스쿼트'),(3,'하체','https://do9nz79ez57wg.cloudfront.net/6f45c544-b688-4468-b287-1f5d1a9e9ce1_바벨힙쓰러스트.gif','바벨 힙 쓰러스트'),(4,'하체','https://do9nz79ez57wg.cloudfront.net/3c0d1474-9991-452f-9228-fde866432960_프론트스쿼트.png','프론트 스쿼트'),(5,'하체','https://do9nz79ez57wg.cloudfront.net/d85b7132-c8a0-45f0-8c7d-4870b4624146_글루트브릿지.png','글루트 브리지'),(6,'하체','https://do9nz79ez57wg.cloudfront.net/474b0214-54cc-43bc-ab5c-43be3b61568a_힙쓰러스트.gif','힙 쓰러스트'),(7,'하체','https://do9nz79ez57wg.cloudfront.net/9ac81b89-e82a-44e6-85e1-0b49fb0bca5a_레그컬.png','레그 컬'),(8,'하체','https://do9nz79ez57wg.cloudfront.net/4d192715-fdf1-4244-84c5-fd9d6af62adf_레그익스텐션.png','레그 익스텐션'),(9,'하체','https://do9nz79ez57wg.cloudfront.net/4d6c0af3-1de3-421b-8b13-eb1711a30df5_레그프레스.png','레그 프레스'),(10,'하체','https://do9nz79ez57wg.cloudfront.net/143d5dd5-e2ed-4aa8-9bfb-d07cfcf8057a_레그레이즈.jpg','레그 레이즈'),(11,'하체','https://do9nz79ez57wg.cloudfront.net/652e402a-e8df-4606-b83b-5d85a6113656_노르딕컬.gif','노르딕 컬'),(12,'하체','https://do9nz79ez57wg.cloudfront.net/fc6ae04b-f595-4b3f-9c5b-3782c4e23c18_오버헤드스쿼트.png','오버헤드 스쿼트'),(13,'하체','https://do9nz79ez57wg.cloudfront.net/f0d438c0-a5b9-43a0-ada8-05eda4b9c3ac_피스톨스쿼트.jpg','피스톨 스쿼트'),(14,'가슴','https://do9nz79ez57wg.cloudfront.net/038dc379-b574-40e2-af35-6776283627ce_베어워크.png','베어 워크'),(15,'가슴','https://do9nz79ez57wg.cloudfront.net/815dc22e-aa74-467d-b4f0-8e735549534e_벤치프레스.png','벤치 프레스'),(16,'가슴','https://do9nz79ez57wg.cloudfront.net/35d87177-2d83-4d61-a78c-5762a28cb110_체스트프레스.png','체스트 프레스'),(17,'가슴','https://do9nz79ez57wg.cloudfront.net/32ac2e63-4015-44a2-9410-8d4d2d2f02d6_디클라인푸시업.jpg','디클라인 푸쉬업'),(18,'가슴','https://do9nz79ez57wg.cloudfront.net/0969a08c-52b5-49b2-985b-d5e0120f8405_버터플라이.png','버터플라이'),(19,'가슴','https://do9nz79ez57wg.cloudfront.net/096275cc-0900-4f80-9d80-86d5b948cd5d_딥스.png','딥스'),(20,'가슴','https://do9nz79ez57wg.cloudfront.net/1125abe6-3e25-47df-a1c5-75a02daf8933_케이블 크로스 오버.png','케이블 크로스 오버'),(21,'가슴','https://do9nz79ez57wg.cloudfront.net/4115d92c-c288-4991-8798-ecfbc460a5b1_인버티드 로우.jpg','인버티드 로우'),(22,'등','https://do9nz79ez57wg.cloudfront.net/447c3eeb-351d-456e-b4e8-264e38fb2fca_백 익스텐션.png','백 익스텐션'),(23,'등','https://do9nz79ez57wg.cloudfront.net/69128b2a-fcc1-4ed2-9c2d-121395d60a48_벤트오버덤벨로우.jpg','벤트오버 덤벨로우'),(24,'등','https://do9nz79ez57wg.cloudfront.net/4b1b0216-655a-406b-acda-f71e4dbc93a6_랫풀다운.jpg','렛풀다운'),(25,'등','https://do9nz79ez57wg.cloudfront.net/127846da-2cc1-4a6f-85c4-1b8d40fe9e4e_풀업.png','풀업'),(26,'등','https://do9nz79ez57wg.cloudfront.net/95fcaa24-45f1-46ea-9279-a594b7954dee_데드리프트.jpeg','데드리프트'),(27,'등','https://do9nz79ez57wg.cloudfront.net/e040d8b6-2f56-43ba-9b5e-c759e15db9d3_케이블 로우.png','케이블로우'),(28,'등','https://do9nz79ez57wg.cloudfront.net/bdfc127a-cd0e-4a38-ba8f-1762578b46a2_티바로우.jpg','티바로우'),(29,'어깨','https://do9nz79ez57wg.cloudfront.net/f249c6e6-b4b8-4577-b179-4ba32632dca3_벤트오버레터럴레이즈.jpg','벤트오버 레터럴 레이즈'),(30,'어깨','https://do9nz79ez57wg.cloudfront.net/9fee03d1-9e94-4a8d-856b-8cf1142c199c_숄더프레스.jpg','숄더 프레스'),(31,'어깨','https://do9nz79ez57wg.cloudfront.net/1eab2336-8403-43e3-8617-5d5ec684c7b2_리버스플라이.jpg','리버스 플라이'),(32,'어깨','https://do9nz79ez57wg.cloudfront.net/d2f08f75-9ec3-4190-a700-cc65fb9e9e3f_프론트레이즈.png','프론트 레이즈'),(33,'어깨','https://do9nz79ez57wg.cloudfront.net/fda0dbf7-470b-4931-be79-0784e5539be5_버스드라이버.jpg','버스 드라이버'),(34,'어깨','https://do9nz79ez57wg.cloudfront.net/111d3dc8-f157-46e7-8b4e-385cd3e871f7_밀리터리프레스.png','밀리터리 프레스'),(35,'어깨','https://do9nz79ez57wg.cloudfront.net/15ed102d-2d2d-4d9b-ad96-1779dd991d98_페이스풀.png','페이스 풀'),(36,'어깨','https://do9nz79ez57wg.cloudfront.net/2a96fd8a-9c5b-4afc-aae0-6bb48ae8fceb_아놀드프레스.jpg','아놀드 프레스'),(37,'팔','https://do9nz79ez57wg.cloudfront.net/fc33f8c6-f6a8-40fb-9bee-fe3c56fc55c9_바벨컬.png','바벨 컬'),(38,'팔','https://do9nz79ez57wg.cloudfront.net/df40d682-08f5-4de5-a5a2-0b9a1bff54b2_덤벨컬.png','덤벨 컬'),(39,'팔','https://do9nz79ez57wg.cloudfront.net/5d3a4a3e-7e35-4dc8-b03d-c2f3c27d5dbc_프리쳐컬.png','프리쳐 컬'),(40,'팔','https://do9nz79ez57wg.cloudfront.net/64c97764-79e2-4e2a-adb4-2495200eeed2_컨센트레이션컬.png','컨센트레이션 컬'),(41,'팔','https://do9nz79ez57wg.cloudfront.net/fb641438-5dee-4f64-8e2f-54bcc46fe915_케이블푸시다운.jpg','케이블 푸시다운'),(42,'팔','https://do9nz79ez57wg.cloudfront.net/2aa2279f-b307-46b0-9dd5-3c0db82df179_킥백.png','킥백'),(43,'팔','https://do9nz79ez57wg.cloudfront.net/4a13604d-b7bb-40e7-bc73-ab6d4a383b99_라잉트라이셉스익스텐션.jpg','라잉 트라이셉스 익스텐션');
/*!40000 ALTER TABLE `training` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-15 22:17:53
