CREATE DATABASE  IF NOT EXISTS `backend` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `backend`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: c204.cjw2k0eykv8p.ap-northeast-2.rds.amazonaws.com    Database: backend
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post` (
  `post_id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `category` enum('NOTICE','FAQ') COLLATE utf8mb4_general_ci NOT NULL,
  `content` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `hit` int NOT NULL DEFAULT '0',
  `is_deleted` bit(1) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`post_id`),
  KEY `FK72mt33dhhs48hf9gcqrq4fxte` (`user_id`),
  CONSTRAINT `FK72mt33dhhs48hf9gcqrq4fxte` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` VALUES (1,'2024-02-09 21:17:14.826305','2024-02-09 21:17:14.826305','NOTICE','3Dbody 플랫폼 서비스에 관심을 가져 주시는 고객 여러분께 감사드립니다. 2월 1일 부터 서비스를 개시합니다. 3Dbody 서비스 이용약관에서 베타 버전에서 얻은 정보와 서비스 이용약관이 일부 개정되어 2024년 2월 1일부터 적용될 예정입니다. 이에 맞추어 회사는 이용약관에 대한 개정사항을 안내 드립니다.',0,_binary '\0','[서비스] 서비스 제공 시작 안내',NULL),(4,'2024-02-09 21:23:01.402195','2024-02-09 21:23:01.402195','NOTICE','안녕하세요, 3Dbody입니다. 3Dbody V1.2 정기 업데이트가 2024년 2월 3일에 진행됩니다.  업데이트 일정: 2023년 7월 13일 오전 중 작업 시간 중에도 3Dbody 서비스를 이용할 수 있으나 서비스 접속이 일시적으로 불안정할 수 있으며, 앱 노출 시간은 앱 스토어 사정에 따라 상이할 수 있습니다.',0,_binary '\0','[업데이트] 3Dbody V1.2 정기 업데이트 소식',NULL),(5,'2024-02-09 21:26:52.040265','2024-02-09 21:26:52.040265','NOTICE','안녕하세요, 3Dbody입니다. 3Dbody 챌린지가 2024년 2월 5일에 진행됩니다. \n\n\n  자세한 안내는 해당 챌린지의 상세 정보를 확인하시기 바랍니다. \n\n 많은 참여 부탁드립니다.\n\n 일정: 2024년 2월 5일 오전 11시 부터 약 1시간 소요 예정 (진행 시간은 챌린지 사정에 따라 상이할 수 있습니다.)',0,_binary '\0','[이벤트] 3Dbody 사용자 플랭크 챌린지 진행 안내ㅣ24년 2월 5(수)',NULL),(6,'2024-02-09 21:28:58.576875','2024-02-09 21:28:58.576875','NOTICE','안녕하세요, 3Dbody입니다. \n\n3Dbody V1.3 정기 업데이트가 2024년 2월 5일에 진행됩니다. \n\n 업데이트 일정: 2024년 2월 5일 오전 중 작업 시간 중에도 3Dbody 서비스를 이용할 수 있으나 서비스 접속이 일시적으로 불안정할 수 있으며, 앱 노출 시간은 앱 스토어 사정에 따라 상이할 수 있습니다.',0,_binary '\0','[업데이트] 3Dbody V1.3 정기 업데이트 소식',NULL),(7,'2024-02-09 21:30:40.070824','2024-02-09 21:30:40.070824','NOTICE','안녕하세요, 3Dbody입니다. \n\n3Dbody V1.4 정기 업데이트가 2024년 2월 5일에 진행됩니다. \n\n 업데이트 일정: 2024년 2월 5일 오전 중 작업 시간 중에도 3Dbody 서비스를 이용할 수 있으나 서비스 접속이 일시적으로 불안정할 수 있으며, 앱 노출 시간은 앱 스토어 사정에 따라 상이할 수 있습니다.',0,_binary '\0','[업데이트] 3Dbody V1.4 정기 업데이트 소식(연속 업데이트 예정)',NULL),(8,'2024-02-09 21:31:55.842932','2024-02-09 21:31:55.842932','NOTICE','안녕하세요, 3Dbody입니다. \n\n3Dbody V2.1 새로운 버전 업데이트가 2024년 2월 5일에 진행됩니다. \n\n 업데이트 일정: 2024년 2월 5일 오전 중 작업 시간 중에도 3Dbody 서비스를 이용할 수 있으나 서비스 접속이 일시적으로 불안정할 수 있으며, 앱 노출 시간은 앱 스토어 사정에 따라 상이할 수 있습니다.',0,_binary '\0','[업데이트] 3Dbody V2.1 버전 업데이트 소식 | 새로운 버전으로 업데이트됩니다.',NULL),(9,'2024-02-09 21:35:53.698931','2024-02-09 21:35:53.698931','FAQ','안녕하세요, 3Dbody입니다. \n\n3Dbody의 일반 사용자는 회원가입을 우선으로 진행해 주셔야 합니다.. \n\n 회원가입 후 로그인을 진행해 주신 후 개인 정보 및 닉네임, 프로필 정보를 수정해 주세요.',0,_binary '\0','[계정] 로그인 어떻게하나요??.',NULL),(10,'2024-02-09 21:39:12.749013','2024-02-09 21:39:12.749013','FAQ','안녕하세요, 3Dbody입니다. \n\n3Dbody의 핀번호는 민감할 수 있는 개인 채성분 정보를 보호하기 위해 필요합니다.. \n\n 하단바 4번째 설정 탭에서 PIN번호 변경을 누른 후 기존 핀 번호를 입력 후 변경할 PIN번호를 입력해 주시면 변경됩니다.',0,_binary '\0','[계정] 핀번호 변경은 어떻게 하나요??',NULL),(11,'2024-02-09 21:42:42.455283','2024-02-09 21:42:42.455283','FAQ','안녕하세요, 3Dbody입니다. \n\n3Dboy의 개인적인 사유로 회원을 탈퇴하신 후 탈퇴 취소를 하기 위해서는 관리자에게 문의해 주시기 바랍니다. \n\n 회원 탈퇴 후에도 1달간 정보를 유지시켜둡니다. 기간이 지난 이후에는 취소가 불가합니다.',0,_binary '\0','[계정] 회원 탈퇴 후 회원 탈퇴 취소는 어떻게 하나요??',NULL),(12,'2024-02-09 21:44:48.646433','2024-02-09 21:44:48.646433','FAQ','안녕하세요, 3Dbody입니다. \n\n3Dboy는 개인의 체형을 3d 가상 모델로 구현하여 목표하는 몸무게와 채성분이 되었을때의 몸을 예측해주는 서비스 입니다. \n\n 부가적으로 운동, 식단을 관리해줍니다.',0,_binary '\0','[솔루션] 3Dbody는 어떤 서비스인가요??',NULL);
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-15 22:17:56
